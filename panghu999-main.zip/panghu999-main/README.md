# 备份
#青龙拉库
ql repo https://ghproxy.com/https://github.com/yanyuwangluo/panghu999.git "jd_"
